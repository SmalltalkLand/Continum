This mock contains basic class and instance method selectors.
