The package AAA has a required package BBB. See [Issue #26](https://github.com/dalehenrich/filetree/issues/26)
