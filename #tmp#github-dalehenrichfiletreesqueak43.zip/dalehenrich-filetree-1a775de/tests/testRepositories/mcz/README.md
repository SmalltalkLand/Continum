This is an empty repository for use with mcz files ... used by tests when they write test packages.
