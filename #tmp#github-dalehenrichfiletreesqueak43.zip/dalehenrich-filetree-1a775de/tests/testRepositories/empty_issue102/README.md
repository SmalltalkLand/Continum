This is an empty repository ... used by tests when they write test packages.


