This is an empty repository ... used by tests when they write test packages.

All of the property files in this repository shoudl be written using a
`.ston` extension.
