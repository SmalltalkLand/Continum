Class used to abstract specific code for the Pharo platform.
