Class used to abstract specific code for the Pharo 3.0 platform.
